#!/bin/bash
# Install application code and dependencies here