#!/bin/bash

# Update the system
sudo apt update -y

# Install git and unzip
sudo apt install -y git unzip

# Install Node.js and npm
sudo apt install -y nodejs npm

# Clone the repository
git clone https://github.com/DemecosChambers/BCFreightAPP.git

# Navigate to the project directory
cd BCFreightAPP

# Unzip the project files (if necessary)
# If your repository has a zip file, uncomment the following line and adjust the file name accordingly
# unzip main.zip

# Install dependencies
npm install

# Start the Node.js app in the background with output redirected to a log file
nohup node index.js > /var/log/freight-app.log 2>&1 &

#You can use the following command to view the log file on your EC2 instance
#sudo tail -f /var/log/freight-app.log